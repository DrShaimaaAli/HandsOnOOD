
public class Account implements IAccount{

	 final static String[] ACCOUNT_TYPES = {"Debit", "Credit", "Saving"};
	   private long accountNumber;
	  
	   private double accountBalance;
	   private String accountType;
	   
	   private UserAccount userAccount = new UserAccount();
	   
	   /**
	     * @return the accountUserName
	     */
	    public String getAccountUserName() {
	        return userAccount.getAccountUserName();
	    }

	    /**
	     * @param accountUserName the accountUserName to set
	     */
	    public void setAccountUserName(String accountUserName) {
	    	userAccount.setAccountUserName(accountUserName);
	    }

	    /**
	     * @return the accountPassword
	     */
	    public String getAccountPassword() {
	        return userAccount.getAccountPassword();
	    }

	    /**
	     * @param accountPassword the accountPassword to set
	     */
	    public void setAccountPassword(String accountPassword) {
	    	userAccount.setAccountPassword(accountPassword);
	    	
	    }

	   
	   public void deposit(double amount)
	   {
//		   if (this.getAccountType().equals("Debit"))
//			   System.out.println("Extra logic needed for debit account");
//		   else if (this.getAccountType().equals("Credit"))
//			   System.out.println("Extra logic needed for credit account");
//		   else if (this.getAccountType().equals("Saving"))
//			   System.out.println("Extra logic needed for saving account");
		   
		   this.setAccountBalance(this.getAccountBalance() + amount);
           System.out.println("New balance is:" + this.getAccountBalance());
	   }
	   
	   public double withdraw(double amount)
	   {
		   
//		   if (this.getAccountType().equals("Debit"))
//			   System.out.println("Extra logic needed for debit account");
//		   else if (this.getAccountType().equals("Credit"))
//			   System.out.println("Extra logic needed for credit account");
//		   else if (this.getAccountType().equals("Saving"))
//			   System.out.println("Extra logic needed for saving account");
		   
		   // make sure there's enough balance before withdrawal
           double currentBalance = this.getAccountBalance();
           double balanceAfterWithdraw = currentBalance - amount;
           if ( balanceAfterWithdraw > 0 )
           {
             /*Logic to instruct the machine to dispense the money*/ 
             this.setAccountBalance(balanceAfterWithdraw);
           }
               
           
           return balanceAfterWithdraw;
	   }
	   
	   /**
	     * @return the accountNumber
	     */
	    public long getAccountNumber() {
	        return accountNumber;
	    }

	    /**
	     * @param accountNumber the accountNumber to set
	     */
	    public void setAccountNumber(long accountNumber) {
	        this.accountNumber = accountNumber;
	    }

	   
	    /**
	     * @return the accountBalance
	     */
	    public double getAccountBalance() {
	        return accountBalance;
	    }

	    /**
	     * @param accountBalance the accountBalance to set
	     */
	    public void setAccountBalance(double accountBalance) {
	        this.accountBalance = accountBalance;
	    }

	    /**
	     * @return the accountType
	     */
	    public String getAccountType() {
	        return accountType;
	    }

	    /**
	     * @param accountType the accountType to set
	     */
	    public void setAccountType(String accountType) {
	        this.accountType = accountType;
	    }

}
