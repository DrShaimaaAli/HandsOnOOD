import java.util.Scanner;
public class ATMSystem {
   
   
    final static String[] ATM_OPTIONS = {"login","choose acct type","deposit","withdraw","exit"};
   
   
    public static void printOptions(String[] options)
    {
    	for (int i=0; i<options.length; i++)
        {
            System.out.println(i +" - " + options[i]);
        }
    }
    
    public static void main(String[] args) {
        
        ATMSystem atm = new ATMSystem();
        IAccount account = new Account();
        //Display available options
        boolean runFlag = true;
        while (runFlag)
        {
	         System.out.println("Please choose the option number:");

	         printOptions(ATMSystem.ATM_OPTIONS);
	         Scanner sc = new Scanner (System.in);
	         int option = sc.nextInt();
	         switch (option)
	         {
	         	case 0:
	         		 System.out.println("Please enter user name:\n");
		             String userName = sc.next();  
		             account.setAccountUserName(userName);
		             
		             System.out.println("Please enter password:\n");
		             String password = sc.next();
		             account.setAccountPassword(password);
	         		break;
	         	case 1:
	         		 System.out.println("Please choose an account type:");

	         		printOptions(Account.ACCOUNT_TYPES);
			         int acct_option = sc.nextInt();
			         //account.setAccountType(Account.ACCOUNT_TYPES[acct_option]);
			         if (acct_option == 0)
			        	 account = new DebitAccount();
			         else if (acct_option == 1)
			        	 account = new CreditAccount();
			         else if (acct_option == 2)
			        	 account = new SavingAccount();
			         //System.out.println("Account type is set to:" + account.getAccountType());
	         		break;
	         	case 2:
	         		 System.out.println("Please enter amount to deposit");
	                 double newAmount = sc.nextDouble();
	                 System.out.println("Please enter cash or check in the deposit box");
	                 /*logic to count cash or scan check*/
	                 account.deposit(newAmount);
	         		
	                 break;
	         	case 3:
	         	    System.out.println("Please enter amount to withdraw:");
                    double amount = sc.nextDouble();
                 
                    double newAm = account.withdraw(amount);
                    if (newAm > 0)
                    {
                    	System.out.println("Please take the money from the cash dispenser");
                    	System.out.println("New balance is:" + account.getAccountBalance());
                    }
                    else
                    	System.out.println("Balance is not sufficient");
	         		break;
	         	default:
	         		System.out.println("Goodbye");
	         		runFlag = false;
	         }
	         
        }
    }
    
}