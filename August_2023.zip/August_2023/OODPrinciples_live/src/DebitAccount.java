
public class DebitAccount extends Account{

	public void deposit(double amount)
	{
		System.out.println("Extra logic needed for debit account");
	}
	
	public double withdraw(double amount)
	{
		System.out.println("Extra logic needed for debit account");
		return super.withdraw(amount);

	}
}
