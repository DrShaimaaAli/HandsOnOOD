
public class CreditAccount extends Account{

	public void deposit(double amount)
	{
		System.out.println("Extra logic needed for credit account");
	}
	
	public double withdraw(double amount)
	{
		System.out.println("Extra logic needed for credit account");
		return super.withdraw(amount);
	}

}
