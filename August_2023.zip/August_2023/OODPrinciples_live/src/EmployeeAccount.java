
public class EmployeeAccount {

	UserAccount userAccount = new UserAccount();
	
}
