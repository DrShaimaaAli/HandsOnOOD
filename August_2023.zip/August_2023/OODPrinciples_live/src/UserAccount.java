
public class UserAccount {
	 private String accountUserName;
	 private String accountPassword;
	 
	 /**
	     * @return the accountUserName
	     */
	    public String getAccountUserName() {
	        return accountUserName;
	    }

	    /**
	     * @param accountUserName the accountUserName to set
	     */
	    public void setAccountUserName(String accountUserName) {
	        this.accountUserName = accountUserName;
	    }

	    /**
	     * @return the accountPassword
	     */
	    public String getAccountPassword() {
	        return accountPassword;
	    }

	    /**
	     * @param accountPassword the accountPassword to set
	     */
	    public void setAccountPassword(String accountPassword) {
	        this.accountPassword = accountPassword;
	    }

}
