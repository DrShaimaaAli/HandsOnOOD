
public class SavingAccount extends Account{

	public void deposit(double amount)
	{
		System.out.println("Extra logic needed for saving account");
	}
	
	public double withdraw(double amount)
	{
		System.out.println("Extra logic needed for saving account");
		return super.withdraw(amount);

	}
}
