
public class Rectangle extends Shape{

	private double width;
	private double hieght;

	public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	public double getHieght() {
		return hieght;
	}

	public void setHieght(double hieght) {
		this.hieght = hieght;
	}
	
	public void calcArea()
	{
		System.out.println("CalcArea in the Rectangle class");
		
	}
	
	public void draw()
	{
		System.out.println("Drawing a Rectangle");
	}
}
