
public class TestDriver {

	public static void drawObject(Drawable drawable)
	{
		System.out.println("Drawing given object on the screen");
		drawable.draw();
	}
	
	public static void main(String[] args) {
		
		Circle c = new Circle();
		c.setX(5);
		c.setY(10);
		c.setRadius(10);
		
		Rectangle r = new Rectangle();
		r.setX(9);
		r.setY(9);
		r.setHieght(10);
		r.setWidth(10);
		
//		Shape s = new Shape();
//		s.setX(0);
//		s.setY(0);
		
//		s = new Circle();
//		s.setX(20);
//		s.setY(20);
//		
//		((Circle)s).setRadius(100);
		
		
		Shape[] shapeAr = new Shape[2];
		//shapeAr[0] = s;
		shapeAr[0] = c;
		shapeAr[1] = r;
		
		for(int i=0; i< shapeAr.length; i++)
		{
			System.out.println("("+shapeAr[i].getX()+","+shapeAr[i].getX()+")");
			shapeAr[i].calcArea();
			drawObject(shapeAr[i]);
		}
		
		
		/*
		Employee emp1 = new Employee();
		emp1.setName("Alice");
		
		Employee emp2 = new Employee();
		emp2.setName("Bob");
		
		
		System.out.println("Emp1: " + emp1.getName());
		System.out.println("Emp2: " + emp2.getName());
		*/
	}
}
