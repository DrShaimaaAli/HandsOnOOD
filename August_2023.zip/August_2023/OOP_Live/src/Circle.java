
public class Circle extends Shape{

	private double radius;

	public double getRadius() {
		return radius;
	}

	public void setRadius(double radius) {
		this.radius = radius;
	}
	
	public void calcArea()
	{
		System.out.println("CalcArea in the Circle class");
	}
	
	public void draw()
	{
		System.out.println("Drawing a circle");
	}
	
}
